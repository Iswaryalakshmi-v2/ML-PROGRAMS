import cv2
import numpy as np
import base64
import os

def preprocess_image(image_path, target_size=(224, 224)):
    """
    Image Preprocessing Pipeline:
    1. Read input image from disk using OpenCV
    2. Convert color space from BGR to RGB
    3. Resize dimensions to fixed (224, 224)
    4. Apply Gaussian Blur (3x3 kernel) for noise reduction
    5. Enhance contrast using CLAHE on LAB luminance channel
    6. Normalize pixel intensity values to [0, 1] floating-point range
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found at path: {image_path}")

    # Step 1: Read image
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Unable to decode image at: {image_path}")

    # Step 2: RGB conversion
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # Step 3: Resize to 224x224
    img = cv2.resize(img, target_size)

    # Step 4: Noise reduction via Gaussian Blur
    img_blur = cv2.GaussianBlur(img, (3, 3), 0)

    # Step 5: CLAHE contrast enhancement in LAB space
    lab = cv2.cvtColor(img_blur, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    l_clahe = clahe.apply(l)
    img_enhanced = cv2.cvtColor(cv2.merge((l_clahe, a, b)), cv2.COLOR_LAB2RGB)

    # Step 6: Normalize to [0, 1]
    img_norm = img_enhanced.astype(np.float32) / 255.0

    return img_norm, img_enhanced

def image_to_base64(image_rgb):
    """Encodes an RGB NumPy image array to a base64 JPEG data URL for web display."""
    img_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    _, buffer = cv2.imencode('.jpg', img_bgr)
    b64_str = base64.b64encode(buffer).decode('utf-8')
    return f"data:image/jpeg;base64,{b64_str}"
