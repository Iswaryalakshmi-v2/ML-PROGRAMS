# Skin Cancer (Melanoma) Detection and Classification using a Multi-Layer Perceptron (MLP) Neural Network

An end-to-end, single-frame interactive web application for automated dermoscopic skin lesion image classification into **Benign Lesion** vs. **Malignant Melanoma** using computer vision and machine learning.

---

## 📋 System Overview
- **Medical Topic**: Automated Skin Cancer & Melanoma Detection from Dermoscopic Lesion Images.
- **Machine Learning Algorithm**: Multi-Layer Perceptron (MLP) Neural Network Classifier (`scikit-learn`).
- **Feature Extraction**: 128-Dimensional Handcrafted Feature Vector (Color Histograms across RGB/LAB channels, Sobel Edge Energy, Spatial Gradients, and Texture Statistics).
- **Backend**: Python 3.x Flask REST API.
- **Frontend**: Responsive Single-Frame Dashboard with HTML5, CSS3, JavaScript, and Chart.js.
- **Database**: SQLite3 diagnostic prediction history persistence (`skincancer.db`).

---

## 📂 Project Directory Structure

```text
SkinCancerClassifier/
├── backend/
│   ├── dataset/
│   │   ├── train/
│   │   │   ├── benign/
│   │   │   └── malignant/
│   │   └── test/
│   │       ├── benign/
│   │       └── malignant/
│   ├── ml/
│   │   ├── preprocessing.py
│   │   └── feature_extraction.py
│   ├── models/
│   │   └── skin_cancer_model.pkl
│   ├── processed/
│   │   ├── features_train.npy
│   │   └── labels_train.npy
│   ├── results/
│   │   └── evaluation_metrics.json
│   ├── routes/
│   │   └── predict.py
│   ├── uploads/
│   ├── database/
│   │   └── skincancer.db
│   ├── app.py
│   ├── config.py
│   ├── database.py
│   ├── populate_dataset_and_train.py
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
└── README.md
```

---

## ⚙️ How to Compile and Run the Code

### 1. Prerequisites
- Python 3.8 to 3.12 installed on your system.
- Visual Studio Code or any code editor / terminal.

### 2. Open the Project in VS Code
Open your terminal / command prompt and navigate to the project directory:
```bash
cd C:\Users\Raj\.gemini\antigravity\scratch\SkinCancerClassifier
```

### 3. Create and Activate a Virtual Environment
**On Windows (PowerShell):**
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```
*(If you encounter execution policy restrictions in PowerShell, run: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`)*

**On Windows (Command Prompt `cmd`):**
```cmd
python -m venv venv
venv\Scripts\activate.bat
```

### 4. Install Required Python Packages
```bash
cd backend
pip install -r requirements.txt
```

### 5. Generate Benchmark Dataset & Train the Neural Network
Run the automated dataset processor and training script:
```bash
python populate_dataset_and_train.py
```
This script will:
1. Organize the dataset and extract the 128-dimensional handcrafted features.
2. Train the Multi-Layer Perceptron (MLP) for 15 epochs using the Adam optimizer with L2 regularization.
3. Compute test performance evaluation metrics (Accuracy, Precision, Recall, F1-Score, and Confusion Matrix).
4. Save the trained model to `backend/models/skin_cancer_model.pkl`.

### 6. Launch the Flask Web Application
```bash
python app.py
```

You will see:
```text
=================================================================
 Skin Cancer (Melanoma) Detection & Classification Web System 
 Multi-Layer Perceptron (MLP) Neural Network 
=================================================================
 -> Server running at: http://127.0.0.1:5000
 -> Open your web browser and navigate to http://127.0.0.1:5000
=================================================================
```

### 7. Open the Web Application
Open your web browser (Chrome, Edge, Firefox) and navigate to:
**`http://127.0.0.1:5000`**

---

## 🖥️ One-Frame Website Application Flow
1. **Step 1 - Load Input Image**: Click "Click or Drag & Drop Dermoscopy Image Here" to upload an image from your computer, or click **"Load Benign Sample"** / **"Load Malignant Sample"** for instant testing.
2. **Step 2 - Image Preprocessing**: View the original image alongside the CLAHE contrast-enhanced and normalized 224×224 output.
3. **Step 3 - Feature Extraction**: Inspect the 128-dimensional numerical feature vector and real-time interactive spatial feature chart.
4. **Step 4 - Neural Network Training**: View the 15-epoch training and validation accuracy and loss curves, and view the epoch console log.
5. **Step 5 - Prediction Result**: View the diagnostic result (**BENIGN LESION (HEALTHY)** in emerald green or **MALIGNANT MELANOMA DETECTED** in crimson red), confidence score, probability bars, and clinical note.
6. **Step 6 - Performance Evaluation**: Inspect test Accuracy, Precision, Recall, F1-Score, and the Confusion Matrix heatmap.
7. **Step 7 - Diagnostic Database History**: View previous classification records stored in SQLite with timestamps, or clear history.
