import cv2
import numpy as np

def extract_features(img):
    """
    Feature Extraction Pipeline:
    1. Color Histograms: 32 bins per channel across 3 color channels (32 * 3 = 96 features), normalized
    2. Spatial Gradients: Horizontal and vertical Sobel edge filters, computing edge energy magnitude
    3. Texture & Statistical Features: Edge energy mean, standard deviation, and regional variance
    Returns:
    - 128-dimensional handcrafted numerical feature vector (float32)
    """
    # 1. Colour histogram (per channel)
    hist_feats = []
    for ch in range(3):
        hist = cv2.calcHist([img], [ch], None, [32], [0, 1])
        hist_norm = cv2.normalize(hist, hist).flatten()
        hist_feats.extend(hist_norm)

    # 2. Spatial gradients using Sobel operators
    gray = cv2.cvtColor((img * 255).astype('uint8'), cv2.COLOR_RGB2GRAY)
    gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    edge_energy = np.sqrt(gx**2 + gy**2)

    grad_feats = [
        float(edge_energy.mean()),
        float(edge_energy.std()),
        float(np.percentile(edge_energy, 90)),
        float(np.percentile(edge_energy, 50))
    ]

    # Additional dermoscopy texture descriptors (contrast, asymmetry proxy)
    h, w = gray.shape
    top_half = gray[:h//2, :]
    bot_half = gray[h//2:, :]
    asymmetry_y = float(np.mean(np.abs(top_half.astype(float) - np.flipud(bot_half).astype(float)))) / 255.0

    left_half = gray[:, :w//2]
    right_half = gray[:, w//2:]
    asymmetry_x = float(np.mean(np.abs(left_half.astype(float) - np.fliplr(right_half).astype(float)))) / 255.0

    extra_feats = [asymmetry_x, asymmetry_y]

    # Combine all extracted features
    features = np.array(hist_feats + grad_feats + extra_feats, dtype=np.float32)

    # Ensure strictly fixed 128 dimensions by padding or truncating
    if len(features) < 128:
        pad_size = 128 - len(features)
        features = np.pad(features, (0, pad_size), 'constant', constant_values=0.0)
    else:
        features = features[:128]

    return features
