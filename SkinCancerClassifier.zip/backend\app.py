import os
from flask import Flask, send_from_directory
from flask_cors import CORS
from config import BASE_DIR, UPLOAD_FOLDER
from routes.predict import predict_bp
from database import init_db

def create_app():
    frontend_dir = os.path.abspath(os.path.join(BASE_DIR, '..', 'frontend'))
    app = Flask(__name__, static_folder=frontend_dir, static_url_path='')
    CORS(app)

    # Initialize SQLite database
    init_db()
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    # Register blueprints
    app.register_blueprint(predict_bp)

    # Serve Single-Frame UI
    @app.route('/')
    def serve_index():
        return send_from_directory(app.static_folder, 'index.html')

    @app.route('/<path:path>')
    def serve_static(path):
        return send_from_directory(app.static_folder, path)

    return app

if __name__ == '__main__':
    app = create_app()
    print("=" * 65)
    print(" Skin Cancer (Melanoma) Detection & Classification Web System ")
    print(" Multi-Layer Perceptron (MLP) Neural Network ")
    print("=" * 65)
    print(" -> Server running at: http://127.0.0.1:5000")
    print(" -> Open your web browser and navigate to http://127.0.0.1:5000")
    print("=" * 65)
    app.run(host='0.0.0.0', port=5000, debug=True)
