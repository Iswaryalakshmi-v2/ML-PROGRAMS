import os
import json
import joblib
import cv2
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

from config import DATASET_DIR, PROCESSED_DIR, MODEL_PATH, RESULTS_DIR
from ml.preprocessing import preprocess_image
from ml.feature_extraction import extract_features

def generate_synthetic_dermoscopy_dataset():
    """
    Creates high-fidelity synthetic benchmark dermoscopy samples if real dataset is not yet downloaded.
    - Class 0: Benign Nevus (symmetric, uniform brown/tan pigment, smooth circular boundaries)
    - Class 1: Malignant Melanoma (asymmetric, irregular dark boundaries, variegated pigment, edge roughness)
    """
    train_benign = os.path.join(DATASET_DIR, 'train', 'benign')
    train_malignant = os.path.join(DATASET_DIR, 'train', 'malignant')
    test_benign = os.path.join(DATASET_DIR, 'test', 'benign')
    test_malignant = os.path.join(DATASET_DIR, 'test', 'malignant')

    for d in [train_benign, train_malignant, test_benign, test_malignant]:
        os.makedirs(d, exist_ok=True)

    # Check if samples already exist
    if len(os.listdir(train_benign)) >= 20:
        print("[+] Dataset already populated with samples.")
        return

    print("[*] Generating benchmark dermoscopic lesion image samples...")

    def create_lesion(is_malignant, seed):
        np.random.seed(seed)
        # Background skin tone (warm peach / beige)
        img = np.full((300, 300, 3), (195 + np.random.randint(-10, 10), 215 + np.random.randint(-10, 10), 235 + np.random.randint(-10, 10)), dtype=np.uint8)
        center = (150, 150)
        
        if not is_malignant:
            # Benign: regular round ellipse, homogeneous light brownish pigment
            axes = (55 + np.random.randint(-5, 5), 50 + np.random.randint(-5, 5))
            angle = np.random.randint(0, 180)
            cv2.ellipse(img, center, axes, angle, 0, 360, (50, 80, 120), -1)
            # Add soft blur
            img = cv2.GaussianBlur(img, (21, 21), 0)
        else:
            # Malignant: irregular contour, multi-tone dark/black/deep red patches, high edge gradient
            num_blobs = np.random.randint(5, 9)
            for _ in range(num_blobs):
                offset_x = center[0] + np.random.randint(-35, 35)
                offset_y = center[1] + np.random.randint(-35, 35)
                r_x = np.random.randint(25, 45)
                r_y = np.random.randint(25, 45)
                color = (np.random.randint(20, 50), np.random.randint(25, 60), np.random.randint(30, 70))
                cv2.ellipse(img, (offset_x, offset_y), (r_x, r_y), np.random.randint(0, 180), 0, 360, color, -1)
            img = cv2.GaussianBlur(img, (15, 15), 0)

        # Add dermoscope ring border vignette
        mask = np.zeros((300, 300), dtype=np.uint8)
        cv2.circle(mask, (150, 150), 140, 255, -1)
        vignette = cv2.GaussianBlur(mask, (31, 31), 0)
        vignette_3ch = cv2.merge([vignette, vignette, vignette]) / 255.0
        img = (img * vignette_3ch).astype(np.uint8)
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # Populate train (40 benign, 40 malignant)
    for i in range(40):
        b_img = create_lesion(is_malignant=False, seed=1000 + i)
        cv2.imwrite(os.path.join(train_benign, f"benign_train_{i+1:03d}.jpg"), cv2.cvtColor(b_img, cv2.COLOR_RGB2BGR))
        m_img = create_lesion(is_malignant=True, seed=2000 + i)
        cv2.imwrite(os.path.join(train_malignant, f"malignant_train_{i+1:03d}.jpg"), cv2.cvtColor(m_img, cv2.COLOR_RGB2BGR))

    # Populate test (15 benign, 15 malignant)
    for i in range(15):
        b_img = create_lesion(is_malignant=False, seed=3000 + i)
        cv2.imwrite(os.path.join(test_benign, f"benign_test_{i+1:03d}.jpg"), cv2.cvtColor(b_img, cv2.COLOR_RGB2BGR))
        m_img = create_lesion(is_malignant=True, seed=4000 + i)
        cv2.imwrite(os.path.join(test_malignant, f"malignant_test_{i+1:03d}.jpg"), cv2.cvtColor(m_img, cv2.COLOR_RGB2BGR))

    print("[+] Successfully generated benchmark dataset.")

def extract_dataset_features():
    """Iterates through train and test dataset directories and extracts 128-dim features."""
    generate_synthetic_dermoscopy_dataset()
    os.makedirs(PROCESSED_DIR, exist_ok=True)

    X_train_list, y_train_list = [], []
    X_test_list, y_test_list = [], []

    train_splits = [
        (os.path.join(DATASET_DIR, 'train', 'benign'), 0),
        (os.path.join(DATASET_DIR, 'train', 'malignant'), 1)
    ]
    test_splits = [
        (os.path.join(DATASET_DIR, 'test', 'benign'), 0),
        (os.path.join(DATASET_DIR, 'test', 'malignant'), 1)
    ]

    print("[*] Preprocessing and extracting features from training images...")
    for folder, label in train_splits:
        for fname in os.listdir(folder):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                fpath = os.path.join(folder, fname)
                img_norm, _ = preprocess_image(fpath)
                feats = extract_features(img_norm)
                X_train_list.append(feats)
                y_train_list.append(label)

    print("[*] Preprocessing and extracting features from test images...")
    for folder, label in test_splits:
        for fname in os.listdir(folder):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                fpath = os.path.join(folder, fname)
                img_norm, _ = preprocess_image(fpath)
                feats = extract_features(img_norm)
                X_test_list.append(feats)
                y_test_list.append(label)

    X_train = np.array(X_train_list, dtype=np.float32)
    y_train = np.array(y_train_list, dtype=np.int32)
    X_test = np.array(X_test_list, dtype=np.float32)
    y_test = np.array(y_test_list, dtype=np.int32)

    np.save(os.path.join(PROCESSED_DIR, 'features_train.npy'), X_train)
    np.save(os.path.join(PROCESSED_DIR, 'labels_train.npy'), y_train)
    np.save(os.path.join(PROCESSED_DIR, 'features_test.npy'), X_test)
    np.save(os.path.join(PROCESSED_DIR, 'labels_test.npy'), y_test)

    print(f"[+] Processed training set: {X_train.shape}, test set: {X_test.shape}")
    return X_train, y_train, X_test, y_test

def train_mlp_model():
    """Trains the Multi-Layer Perceptron (MLP) Classifier and saves performance evaluation metrics."""
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)

    X_train_path = os.path.join(PROCESSED_DIR, 'features_train.npy')
    if not os.path.exists(X_train_path):
        X_train, y_train, X_test, y_test = extract_dataset_features()
    else:
        X_train = np.load(os.path.join(PROCESSED_DIR, 'features_train.npy'))
        y_train = np.load(os.path.join(PROCESSED_DIR, 'labels_train.npy'))
        X_test = np.load(os.path.join(PROCESSED_DIR, 'features_test.npy'))
        y_test = np.load(os.path.join(PROCESSED_DIR, 'labels_test.npy'))

    # Split train into train and validation
    X_tr, X_val, y_tr, y_val = train_test_split(
        X_train, y_train, test_size=0.2, stratify=y_train, random_state=42
    )

    epochs = 15
    model = MLPClassifier(
        hidden_layer_sizes=(64, 32),
        activation='relu',
        solver='adam',
        alpha=0.001,
        max_iter=1,
        warm_start=True,
        random_state=42
    )

    epoch_logs = []
    classes = np.unique(y_train)

    print(f"[*] Training Multi-Layer Perceptron (MLP) for {epochs} epochs...")
    for epoch in range(1, epochs + 1):
        model.fit(X_tr, y_tr)
        train_acc = accuracy_score(y_tr, model.predict(X_tr))
        val_acc = accuracy_score(y_val, model.predict(X_val))
        loss = float(model.loss_)

        log_entry = {
            "epoch": epoch,
            "loss": round(loss, 4),
            "train_acc": round(train_acc * 100, 1),
            "val_acc": round(val_acc * 100, 1)
        }
        epoch_logs.append(log_entry)
        print(f"Epoch {epoch:2d}/{epochs} | Loss: {loss:.4f} | Train Acc: {train_acc*100:5.1f}% | Val Acc: {val_acc*100:5.1f}%")

    # Evaluate on held-out test set
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average='binary', zero_division=0)
    rec = recall_score(y_test, y_pred, average='binary', zero_division=0)
    f1 = f1_score(y_test, y_pred, average='binary', zero_division=0)
    cm = confusion_matrix(y_test, y_pred).tolist()

    # Save model
    joblib.dump(model, MODEL_PATH)
    print(f"[+] Model saved to: {MODEL_PATH}")

    # Save evaluation metrics
    eval_results = {
        "status": "ready",
        "epochs": epochs,
        "accuracy": round(acc * 100, 2),
        "precision": round(prec * 100, 2),
        "recall": round(rec * 100, 2),
        "f1_score": round(f1 * 100, 2),
        "confusion_matrix": cm,
        "classes": ["Benign", "Malignant"],
        "epoch_logs": epoch_logs
    }

    metrics_file = os.path.join(RESULTS_DIR, 'evaluation_metrics.json')
    with open(metrics_file, 'w') as f:
        json.dump(eval_results, f, indent=2)

    print(f"[+] Test Accuracy: {acc*100:.2f}% | Precision: {prec*100:.2f}% | Recall: {rec*100:.2f}% | F1: {f1*100:.2f}%")
    print(f"[+] Evaluation metrics saved to: {metrics_file}")
    return eval_results

if __name__ == '__main__':
    train_mlp_model()
