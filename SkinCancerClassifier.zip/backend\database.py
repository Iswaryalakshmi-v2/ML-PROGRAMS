import sqlite3
import datetime
import os
from config import DB_PATH

def init_db():
    """Initializes the SQLite database and history table if not present."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        prediction TEXT NOT NULL,
        confidence REAL NOT NULL,
        created_at TEXT NOT NULL
    )''')
    conn.commit()
    conn.close()

def log_prediction(filename, prediction, confidence):
    """Logs a single classification record to the SQLite database."""
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    created_at = datetime.datetime.now().strftime("%d/%m/%Y, %I:%M:%S %p")
    cur.execute(
        'INSERT INTO history (filename, prediction, confidence, created_at) VALUES (?, ?, ?, ?)',
        (filename, prediction, float(confidence), created_at)
    )
    conn.commit()
    record_id = cur.lastrowid
    conn.close()
    return record_id

def get_history(limit=50):
    """Retrieves previous prediction records from the database ordered by newest first."""
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute('SELECT id, filename, prediction, confidence, created_at FROM history ORDER BY id DESC LIMIT ?', (limit,))
    rows = cur.fetchall()
    history = [dict(row) for row in rows]
    conn.close()
    return history

def clear_history():
    """Clears all prediction records from history table."""
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('DELETE FROM history')
    conn.commit()
    conn.close()
    return True
