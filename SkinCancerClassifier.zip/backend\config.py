import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# File storage paths
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
MODEL_PATH = os.path.join(BASE_DIR, 'models', 'skin_cancer_model.pkl')
DB_PATH = os.path.join(BASE_DIR, 'database', 'skincancer.db')
PROCESSED_DIR = os.path.join(BASE_DIR, 'processed')
RESULTS_DIR = os.path.join(BASE_DIR, 'results')
DATASET_DIR = os.path.join(BASE_DIR, 'dataset')

# Allowed extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp', 'tiff'}

# Target classes
CLASSES = ['Benign Lesion', 'Malignant Melanoma']

# Feature vector size
FEATURE_DIM = 128
